// useFloat: a popover (the people picker's list, the date field's calendar)
// that must not be cut at the edge of a dialog. Inside a <dialog> — which
// scrolls its own content (overflow: auto) — an absolutely placed list was
// clipped at the dialog's edge. There, the popover is placed `fixed` against
// the viewport, under its field (or above it when there is no room below),
// and follows it when the dialog scrolls or the window changes size. A
// fixed element escapes its ancestors' overflow; the dialog is in the top
// layer, so it stays on top. Outside a dialog nothing changes (the CSS
// places it).
//
// Positions are set through the CSSOM (element.style), never a style
// attribute: the studio's style policy (nonces, no inline style) allows it.
import { useLayoutEffect, type RefObject } from "react";

export function useFloat(anchor: RefObject<HTMLElement | null>, float: RefObject<HTMLElement | null>, open: boolean, { matchWidth = false, scroll = true, gap = 4 }: { matchWidth?: boolean; scroll?: boolean; gap?: number } = {}): void {
  useLayoutEffect(() => {
    const a = anchor.current;
    const f = float.current;
    if (!open || !a || !f || !a.closest("dialog")) return;
    const place = () => {
      const r = a.getBoundingClientRect();
      const width = matchWidth ? r.width : f.offsetWidth;
      const height = f.offsetHeight;
      const below = window.innerHeight - r.bottom - gap;
      const above = r.top - gap;
      const top = below >= height || below >= above ? r.bottom + gap : Math.max(gap, r.top - gap - height);
      const left = Math.max(gap, Math.min(r.left, window.innerWidth - width - gap));
      f.style.position = "fixed";
      f.style.top = `${Math.round(top)}px`;
      f.style.left = `${Math.round(left)}px`;
      f.style.right = "auto";
      f.style.margin = "0";
      if (matchWidth) f.style.width = `${Math.round(width)}px`;
      // No room either side: a list scrolls within what is left.
      if (scroll) f.style.maxHeight = `min(320px, 50vh, ${Math.max(120, Math.round(Math.max(below, above)))}px)`;
    };
    place();
    window.addEventListener("scroll", place, true);
    window.addEventListener("resize", place);
    return () => {
      window.removeEventListener("scroll", place, true);
      window.removeEventListener("resize", place);
      for (const p of ["position", "top", "left", "right", "margin", "width", "maxHeight"] as const) f.style[p] = "";
    };
  });
}
