import { createHash, createHmac, randomBytes } from "node:crypto";
import { createServer, type IncomingMessage, type ServerResponse } from "node:http";
import type { AddressInfo } from "node:net";
import type { ChestEvent } from "./events.js";
import { groupIdPattern, memberIdPattern, type Member } from "./member.js";
import { forget } from "./members.js";

// For a tool's own tests, never imported by its production code: a member's
// assertion signed as the Chest signs it, and a Chest's API in the test's
// process that answers members, groups, files (stat, move, links; an upload
// it authorises but does not receive), badges, notifications and the
// acknowledgment of an erasure with the Chest's bounds, quotas and errors;
// and that delivers an event to the tool, signed as the Chest signs it.
//
//   import { fakeChest, withMember } from "@argentic/chest-sdk/testing";
//   const chest = await fakeChest({ members: [camille], capabilities: ["members", "files", "notifications"] });
//   const response = await app(withMember(new Request("http://tool/chest"), camille));
//   assert.equal(chest.notifications[0]?.member, camille.id);
//   assert.equal(await chest.emit({ type: "access.revoked", data: { id: camille.id } }, request => app(request)), 204);
//   await chest.close();

// A member as a test names them: a Member, whose locale may be left out
// (the Chest then says none, and the tool reads English).
export type FakeMember = Omit<Member, "locale"> & { locale?: string };

// A group as a fake Chest keeps it: its identifier, its name, and the
// identifiers of the members it gives the tool to.
export type FakeGroup = { id: string; name: string; members: string[] };
// A file as a fake Chest keeps it.
export type FakeFile = { data: Uint8Array; type: string; updated: string };
// A notification as a fake Chest keeps it: the member it went to, its text
// cleaned as the Chest cleans it, its path (/chest when not said) and its
// key.
export type FakeNotification = { member: string; title: string; body?: string; path: string; key?: string };

// What a fake Chest is given: the members who have the tool, those who left
// it (erased: their data was erased, the name gone), its groups, the
// capabilities its version holds (a capability left out answers 403;
// members, files and notifications by default, members.email to read the
// addresses), the events it receives (["member.*"] by default, [] to answer
// an acknowledgment 403), the files it keeps, and the origin of the team
// host its links and uploads point to (https://<tool>-chest.chest.test by
// default; a harness gives its own, http://localhost:<port>, and relays
// /_chest/ to the fake Chest's address).
export type FakeChestOptions = {
  members?: FakeMember[];
  former?: { id: string; name?: string; erased?: boolean }[];
  groups?: FakeGroup[];
  capabilities?: string[];
  receives?: string[];
  files?: Record<string, { data: Uint8Array | string; type?: string }>;
  origin?: string;
  schedules?: { name: string; cron: string }[];
  timeZone?: string;
  // Proposal (studio): the events this tool publishes (chest.json "emits"),
  // and how many tools receive them.
  emits?: string[];
  receivers?: number;
  // Proposal (studio): the storage spec's public uploads and public files.
  storage?: { publicUploads?: boolean; publicFiles?: boolean; publicOrigin?: string };
  // Proposal (studio): mail (with "mail" in capabilities).
  mail?: { domain?: string; mailboxes?: string[]; perDay?: number; suppressed?: string[] };
};

// A message the tool sent, as the fake Chest's outbox keeps it (addresses
// resolved, members' included).
export type FakeMail = { id: string; messageId: string; from: string; fromName: string | null; to: string[]; cc: string[]; subject: string; text: string; html?: string; replyTo?: string; inReplyTo?: string; references?: string[]; attachments: { name: string; type: string; size: number }[]; key?: string; status: "sent" };
// A message to deliver to the tool, as someone outside would write it.
export type FakeIncoming = { mailbox: string; from: string; fromName?: string; subject: string; text: string; html?: string; to?: string[]; cc?: string[]; inReplyTo?: string; references?: string[]; attachments?: { name: string; type: string; content: string | Uint8Array }[]; spam?: number };

// An event for emit: its type and data; its id (a new evt_… by default) and
// when it happened (now by default) may be named, to deliver the same event
// twice.
export type FakeEvent = { [K in ChestEvent["type"]]: { type: K; data: Extract<ChestEvent, { type: K }>["data"]; id?: string; occurredAt?: string } }[ChestEvent["type"]];

// A fake Chest in the test's process: its address, the token and the tool it
// set in the environment, what it keeps (members, groups and files a test
// changes or reads; the notifications the tool sent, in the order sent, a
// replaced one last; each member's badge; the erasures the tool
// acknowledged), upload, which sends a file to an uploadUrl as a member's
// browser would, emit, which delivers an event to the tool — POST
// /chest-events of its address, or a handler of Web Requests — and says the
// status it answered, and close, which stops it and restores the
// environment. Its members are those who have the tool: the others are
// skipped.
export type FakeChest = {
  api: string;
  token: string;
  tool: string;
  members: FakeMember[];
  groups: FakeGroup[];
  files: Map<string, FakeFile>;
  notifications: FakeNotification[];
  badges: Map<string, number>;
  acknowledged: string[];
  emit(event: FakeEvent, to: string | ((request: Request) => Response | Promise<Response>)): Promise<number>;
  upload(url: string, data: Uint8Array | string, type: string): Promise<Response>;
  // Proposal (studio): the tool's schedules, the runs delivered, and run(),
  // which delivers a run of a schedule as the Chest would at its time.
  // Proposal (studio): the events the tool published, and deliver(), which
  // hands the tool an event of another tool as the Chest would.
  published: { id: string; type: string; data: Record<string, unknown>; key?: string }[];
  deliver(event: { type: string; source?: string; data: Record<string, unknown>; id?: string; occurredAt?: string }, to: string | ((request: Request) => Response | Promise<Response>)): Promise<number>;
  // Proposal (studio): the mail the tool sent, and receive(), which delivers
  // a message to its POST /chest-mail as the Chest would.
  outbox: FakeMail[];
  receive(message: FakeIncoming, to: string | ((request: Request) => Response | Promise<Response>)): Promise<number>;
  schedules: { name: string; cron: string }[];
  runs: { id: string; name: string; scheduledAt: string; attempt: number; status: number }[];
  run(name: string, to: string | ((request: Request) => Response | Promise<Response>), options?: { id?: string; scheduledAt?: string; attempt?: number }): Promise<number>;
  close(): Promise<void>;
};

const encode = (value: unknown): string => Buffer.from(JSON.stringify(value)).toString("base64url");

// signAssertion is the Chest-Member value the Chest's front would send for
// that member: HS256 under the key of the token (CHEST_TOKEN by default), for
// the tool (CHEST_TOOL by default), valid 60 seconds from now.
export function signAssertion(member: FakeMember, options: { token?: string; tool?: string; now?: Date } = {}): string {
  const token = options.token ?? process.env["CHEST_TOKEN"];
  const tool = options.tool ?? process.env["CHEST_TOOL"];
  if (!token || !tool) throw new Error("signAssertion needs a token and a tool: start a fakeChest, or name them");
  if (!memberIdPattern.test(member.id) || !member.groups.every(g => groupIdPattern.test(g))) throw new Error("signAssertion needs identifiers of the Chest's shape (mbr_…, grp_…)");
  const iat = Math.floor((options.now ?? new Date()).getTime() / 1000);
  const body = encode({ alg: "HS256", typ: "JWT" }) + "." + encode({
    iss: `https://${tool}-chest.chest.test`, aud: tool, iat, exp: iat + 60, sub: member.id,
    given_name: member.firstName, family_name: member.lastName, name: member.name, picture: member.photo ?? "", role: member.role ?? "",
    admin: member.isAdmin, builder: member.isBuilder, groups: member.groups, ...(member.email === undefined ? {} : { email: member.email }), ...(member.locale === undefined ? {} : { locale: member.locale }),
  });
  // The key as the Chest derives it, and member() reads it: HMAC-SHA256 of
  // the label of the assertion's shape under the text of the token.
  const key = createHmac("sha256", Buffer.from(token, "utf8")).update("Chest-Member v2").digest();
  return body + "." + createHmac("sha256", key).update(body).digest("base64url");
}

// signEvent is the Chest-Event value the Chest would send with that body:
// HS256 under the key the token derives for events, for the tool, naming the
// event and the digest of the body, valid 60 seconds.
function signEvent(id: string, body: string, options: { token: string; tool: string; label?: string }): string {
  const iat = Math.floor(Date.now() / 1000);
  const signed = encode({ alg: "HS256", typ: "JWT" }) + "." + encode({ aud: options.tool, iat, exp: iat + 60, jti: id, digest: createHash("sha256").update(body).digest("base64url") });
  const key = createHmac("sha256", Buffer.from(options.token, "utf8")).update(options.label ?? "Chest-Event v1").digest();
  return signed + "." + createHmac("sha256", key).update(signed).digest("base64url");
}

// withMember is the request carrying that member's assertion: a new Web
// Request, or the same Node request with its header set.
export function withMember<R extends Request | IncomingMessage>(request: R, member: FakeMember, options: { token?: string; tool?: string; now?: Date } = {}): R {
  const assertion = signAssertion(member, options);
  if (request instanceof Request) {
    const headers = new Headers(request.headers);
    headers.set("Chest-Member", assertion);
    return new Request(request, { headers }) as R;
  }
  (request as IncomingMessage).headers["chest-member"] = assertion;
  return request;
}

// The bounds of a Chest (chest/toolmembers, chest/toolfiles).
const maxLimit = 500, defaultLimit = 100, maxLookup = 200, callsPerMinute = 600;
const maxObject = 32 << 20, maxObjects = 10000, maxTotal = 1 << 30;
const namePattern = /^[A-Za-z0-9][A-Za-z0-9._-]{0,99}(\/[A-Za-z0-9][A-Za-z0-9._-]{0,99}){0,7}$/u;
// Its notifications: recipients and badges a call, text, quotas.
const maxRecipients = 500, maxTitle = 80, maxText = 280, maxPath = 512, maxCount = 9999;
const recipientsPerHour = 1000, itemsPerDay = 100, badgesPerMinute = 600;
const keyPattern = /^[a-z0-9._:-]{1,64}$/u;
const reordering = /[\u061c\u200e\u200f\u202a-\u202e\u2066-\u2069]/gu;
const cleanTitle = (s: string): string => s.replace(/[\t\r\n]/gu, " ").replace(/\p{Cc}/gu, "").replace(reordering, "").trim();
const cleanText = (s: string): string => s.replace(/\r\n?/gu, "\n").replace(/\t/gu, " ").replace(/[^\P{Cc}\n]/gu, "").replace(reordering, "").trim();
const isPath = (p: unknown): boolean => typeof p === "string" && p.length <= maxPath && /^\/chest([/?#][\x21-\x5b\x5d-\x7e]*)?$/u.test(p) && !p.includes("//") && !p.split(/[?#]/u)[0]!.split("/").some(x => /^(\.|%2e){1,2}$/iu.test(x));

const fold = (s: string): string => s.normalize("NFD").replace(/\p{Mn}/gu, "").toLowerCase();

function send(response: ServerResponse, status: number, value?: unknown, headers: Record<string, string> = {}): void {
  if (value === undefined) return void response.writeHead(status, headers).end();
  const raw = JSON.stringify(value);
  response.writeHead(status, { ...headers, "Content-Type": "application/json", "Content-Length": String(Buffer.byteLength(raw)) }).end(raw);
}
async function body(request: IncomingMessage, limit: number): Promise<Buffer | null> {
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const chunk of request) {
    size += (chunk as Buffer).length;
    if (size > limit) return null;
    chunks.push(chunk as Buffer);
  }
  return Buffer.concat(chunks);
}

// fakeChest starts a Chest's API on 127.0.0.1 and points the environment at
// it: CHEST_API, CHEST_TOKEN (a new one) and CHEST_TOOL ("tool" unless the
// environment names one). What member() and the modules of the SDK read is
// then this Chest's.
export async function fakeChest(options: FakeChestOptions = {}): Promise<FakeChest> {
  const capabilities = new Set(options.capabilities ?? ["members", "files", "notifications"]);
  const email = capabilities.has("members.email");
  const tool = process.env["CHEST_TOOL"] || "tool";
  const token = randomBytes(32).toString("base64url");
  const files = new Map<string, FakeFile>();
  for (const [name, file] of Object.entries(options.files ?? {})) {
    files.set(name, { data: typeof file.data === "string" ? new TextEncoder().encode(file.data) : file.data, type: file.type ?? "application/octet-stream", updated: new Date().toISOString() });
  }
  const receives = options.receives ?? ["member.*"];
  // Where the team host's links point: the harness that relays /_chest/
  // here, or a host of no one in a test.
  const origin = (options.origin ?? `https://${tool}-chest.chest.test`).replace(/\/$/u, "");
  const uploads = new Map<string, { name: string; types: string[]; maxSize: number; expires: number; public: boolean }>();
  const storage = options.storage ?? {};
  // The public host's origin: the harness serves both hosts on one.
  const publicOrigin = (storage.publicOrigin ?? options.origin ?? `https://${tool}.chest.test`).replace(/\/$/u, "");
  const publicMaxObject = 10 << 20;
  // The erasures the tool was told of, by emit: those it may acknowledge.
  const erasures = new Set<string>();
  const chest: FakeChest = { api: "", token, tool, members: [...(options.members ?? [])], groups: [...(options.groups ?? [])], files, notifications: [], badges: new Map(), acknowledged: [], emit: async () => 0, upload: async () => new Response(), published: [], deliver: async () => 0, outbox: [], receive: async () => 0, schedules: [...(options.schedules ?? [])], runs: [], run: async () => 0, close: async () => {} };
  const former = [...(options.former ?? [])];
  let window = 0, calls = 0;
  const shown = (m: FakeMember) => ({ id: m.id, first_name: m.firstName, last_name: m.lastName, name: m.name, photo: m.photo, role: m.role, admin: m.isAdmin, builder: m.isBuilder, groups: m.groups, ...(m.locale === undefined ? {} : { locale: m.locale }), ...(email && m.email !== undefined ? { email: m.email } : {}) });
  const key = (m: FakeMember) => fold(m.name) + "\u0000" + m.id;
  const described = (name: string, f: FakeFile) => ({ name, type: f.type, size: f.data.byteLength, updated: f.updated });

  async function members(request: IncomingMessage, response: ServerResponse, url: URL): Promise<void> {
    if (!capabilities.has("members")) return send(response, 403, { error: "capability_not_granted" });
    const now = Date.now();
    if (now - window >= 60_000) [window, calls] = [now, 0];
    if (++calls > callsPerMinute) return send(response, 429, { error: "rate_limited" }, { "Retry-After": "60" });
    if (request.method === "GET" && url.pathname === "/members") {
      const q = url.searchParams, keys = [...q.keys()];
      const limit = q.has("limit") ? Number(q.get("limit")) : defaultLimit;
      const after = q.has("after") ? Buffer.from(q.get("after")!, "base64url").toString() : "";
      if (q.has("after") && !memberIdPattern.test(after.split("\u0000")[1] ?? "")) return send(response, 400, { error: "invalid_query" });
      const group = q.get("group"), role = q.get("role"), search = fold(q.get("q") ?? "");
      if (keys.some(k => !["after", "limit", "q", "role", "group"].includes(k) || q.getAll(k).length !== 1) || !Number.isInteger(limit) || limit < 1 || limit > maxLimit || String(limit) !== (q.get("limit") ?? String(defaultLimit)) || (group !== null && !groupIdPattern.test(group)) || search.length > 64) return send(response, 400, { error: "invalid_query" });
      const shownList = chest.members
        .filter(m => (role === null || m.role === role) && (group === null || m.groups.includes(group)) && (search === "" || [m.firstName, m.lastName, m.name, ...(email && m.email ? [m.email] : [])].some(n => fold(n).startsWith(search))))
        .filter(m => after === "" || key(m) > after)
        .sort((a, b) => key(a) < key(b) ? -1 : key(a) > key(b) ? 1 : 0);
      const page = shownList.slice(0, limit);
      return send(response, 200, { members: page.map(shown), next: shownList.length > limit ? Buffer.from(key(page.at(-1)!)).toString("base64url") : null });
    }
    if (request.method === "POST" && url.pathname === "/members/lookup") {
      const raw = await body(request, 64 << 10);
      let ids: unknown;
      try { ids = (JSON.parse(raw?.toString() ?? "") as { ids?: unknown }).ids; } catch { ids = undefined; }
      if (!Array.isArray(ids) || ids.length > maxLookup) return send(response, 400, { error: "invalid_body" });
      if (!ids.every(id => typeof id === "string" && memberIdPattern.test(id))) return send(response, 400, { error: "invalid_id" });
      const answer = { members: [] as unknown[], former: [] as unknown[], unknown: [] as string[] };
      for (const id of new Set(ids as string[])) {
        const m = chest.members.find(x => x.id === id), f = former.find(x => x.id === id);
        if (m) answer.members.push(shown(m));
        else if (f?.erased) answer.former.push({ id, status: "erased" });
        else if (f) answer.former.push({ id, ...(f.name ? { name: f.name } : {}), status: "former" });
        else answer.unknown.push(id);
      }
      return send(response, 200, answer);
    }
    if (request.method === "GET" && url.pathname.startsWith("/members/")) {
      const id = url.pathname.slice("/members/".length);
      if (!memberIdPattern.test(id)) return send(response, 400, { error: "invalid_id" });
      const m = chest.members.find(x => x.id === id);
      return m ? send(response, 200, shown(m)) : send(response, 404, { error: "member_not_found" });
    }
    if (request.method === "GET" && url.pathname === "/groups") return send(response, 200, { groups: chest.groups });
    send(response, 404, { error: "not_found" });
  }

  async function filesRoute(request: IncomingMessage, response: ServerResponse, url: URL): Promise<void> {
    if (!capabilities.has("files")) return send(response, 403, { error: "capability_not_granted" });
    if (request.method === "GET" && url.pathname === "/files") {
      const prefix = url.searchParams.get("prefix") ?? "", after = url.searchParams.get("after") ?? "";
      const names = [...files.keys()].filter(n => n.startsWith(prefix) && n > after).sort();
      return send(response, 200, { files: names.slice(0, 1000).map(n => described(n, files.get(n)!)), next: names.length > 1000 ? names[999] : null });
    }
    if (request.method === "POST" && url.pathname === "/files/url") {
      const raw = await body(request, 4096);
      let name: unknown;
      try { name = (JSON.parse(raw?.toString() ?? "") as { name?: unknown }).name; } catch { name = undefined; }
      if (typeof name !== "string") return send(response, 400, { error: "invalid_body" });
      if (!files.has(name)) return send(response, 404, { error: "not_found" });
      return send(response, 200, { url: `${origin}/_chest/files/${Buffer.from(name).toString("base64url")}.fake`, expires_in: 900 });
    }
    if (request.method === "POST" && (url.pathname === "/files/move" || url.pathname === "/files/upload-url")) {
      const raw = await body(request, 4096);
      let command: Record<string, unknown> = {};
      try { command = JSON.parse(raw?.toString() ?? "") as Record<string, unknown>; } catch { command = {}; }
      if (url.pathname === "/files/upload-url") {
        // The upload itself goes from a member's browser to the team host:
        // the fake Chest's front receives it (PUT /_chest/files/upload/…,
        // or chest.upload in a test), once, within its bounds.
        const name = command["name"], types = command["types"], maxSize = command["max_size"], life = command["expires_in"], isPublic = command["public"] === true;
        if (typeof name !== "string" || !(name.endsWith("/") ? namePattern.test(name.slice(0, -1)) : namePattern.test(name))) return send(response, 400, { error: "invalid_name" });
        if (types !== undefined && (!Array.isArray(types) || !types.every(t => typeof t === "string"))) return send(response, 400, { error: "invalid_type" });
        if (isPublic && !storage.publicUploads) return send(response, 403, { error: "capability_not_granted" });
        if (isPublic && !name.startsWith("uploads/public/")) return send(response, 400, { error: "invalid_name" });
        const expiresIn = typeof life === "number" ? life : 900;
        const token = randomBytes(18).toString("base64url") + ".up";
        const bound = isPublic ? publicMaxObject : maxObject;
        uploads.set(token, { name, types: (types as string[] | undefined) ?? [], maxSize: typeof maxSize === "number" ? Math.min(maxSize, bound) : bound, expires: Date.now() + expiresIn * 1000, public: isPublic });
        return send(response, 200, { url: isPublic ? `${publicOrigin}/_chest/upload/${token}` : `${origin}/_chest/files/upload/${token}`, method: "PUT", expires_in: expiresIn });
      }
      const from = command["from"], to = command["to"];
      if (typeof from !== "string" || typeof to !== "string" || !namePattern.test(from) || !namePattern.test(to)) return send(response, 400, { error: "invalid_name" });
      const moving = files.get(from);
      if (!moving) return send(response, 404, { error: "not_found" });
      files.delete(from);
      files.set(to, moving);
      return send(response, 200, described(to, moving));
    }
    const name = decodeURIComponent(url.pathname.slice("/files/".length));
    if (!namePattern.test(name)) return send(response, 400, { error: "invalid_name" });
    const object = files.get(name);
    if (request.method === "PUT") {
      const data = await body(request, maxObject);
      if (data === null) return send(response, 413, { error: "too_large" });
      const total = [...files.entries()].reduce((sum, [n, f]) => n === name ? sum : sum + f.data.byteLength, 0);
      if (total + data.length > maxTotal || (!object && files.size >= maxObjects)) return send(response, 429, { error: "quota_exceeded" });
      const kept = { data: new Uint8Array(data), type: request.headers["content-type"] ?? "application/octet-stream", updated: new Date().toISOString() };
      files.set(name, kept);
      return send(response, 201, described(name, kept));
    }
    if (!object) return send(response, 404, { error: "not_found" });
    if (request.method === "GET" && url.searchParams.has("stat")) return send(response, 200, described(name, object));
    if (request.method === "GET") return void response.writeHead(200, { "Content-Type": object.type, "Content-Length": String(object.data.byteLength) }).end(object.data);
    if (request.method === "DELETE") {
      files.delete(name);
      return send(response, 204);
    }
    send(response, 404, { error: "not_found" });
  }

  // The windows of the notification quotas, each from the first call it
  // counts: the tool's recipients this hour, each member's items this day,
  // the tool's badge writes this minute.
  type Window = { start: number; count: number };
  const hour: Window = { start: 0, count: 0 }, minute: Window = { start: 0, count: 0 }, days = new Map<string, Window>();
  const live = (w: Window | undefined, span: number, now: number): boolean => w !== undefined && w.count > 0 && now - w.start < span;
  const wait = (w: Window, span: number, now: number): Record<string, string> => ({ "Retry-After": String(Math.max(1, Math.ceil((w.start + span - now) / 1000))) });
  const count = (w: Window, span: number, now: number, n: number): void => {
    if (!live(w, span, now)) [w.start, w.count] = [now, 0];
    w.count += n;
  };
  const access = (id: string) => chest.members.some(m => m.id === id);
  // drop removes kept notifications in place: a test may hold the list.
  const drop = (gone: (n: FakeNotification) => boolean): void => {
    for (let i = chest.notifications.length - 1; i >= 0; i--) if (gone(chest.notifications[i]!)) chest.notifications.splice(i, 1);
  };
  // recipients reads 1 to 500 member identifiers, each once.
  function recipients(value: unknown): string[] | { error: string } {
    if (!Array.isArray(value) || value.length < 1 || value.length > maxRecipients) return { error: "invalid_body" };
    if (!value.every(v => typeof v === "string" && memberIdPattern.test(v))) return { error: "invalid_id" };
    return [...new Set(value as string[])];
  }

  async function notificationsRoute(request: IncomingMessage, response: ServerResponse, url: URL): Promise<void> {
    if (!capabilities.has("notifications")) return send(response, 403, { error: "capability_not_granted" });
    const badge = request.method === "PUT" && url.pathname.startsWith("/badges/");
    if (!badge && !(request.method === "PUT" && url.pathname === "/badges") && !(request.method === "POST" && (url.pathname === "/notifications" || url.pathname === "/notifications/withdraw"))) return send(response, 404, { error: "not_found" });
    const raw = await body(request, 64 << 10);
    let command: Record<string, unknown> | null = null;
    try {
      const value = JSON.parse(raw?.toString() ?? "") as unknown;
      if (value !== null && typeof value === "object" && !Array.isArray(value)) command = value as Record<string, unknown>;
    } catch {
      command = null;
    }
    const keys = (...allowed: string[]) => command !== null && Object.keys(command).every(k => allowed.includes(k));
    const now = Date.now();
    if (badge || url.pathname === "/badges") {
      let writes: { member: string; count: number }[];
      if (badge) {
        const id = url.pathname.slice("/badges/".length);
        if (!memberIdPattern.test(id)) return send(response, 400, { error: "invalid_id" });
        if (!keys("count") || !("count" in command!)) return send(response, 400, { error: "invalid_body" });
        writes = [{ member: id, count: command!["count"] as number }];
      } else {
        const list = command?.["badges"];
        if (!keys("badges") || !Array.isArray(list) || list.length < 1 || list.length > maxRecipients || !list.every(b => b !== null && typeof b === "object" && !Array.isArray(b) && Object.keys(b).every(k => k === "member" || k === "count"))) return send(response, 400, { error: "invalid_body" });
        writes = list as { member: string; count: number }[];
        if (!writes.every(b => typeof b.member === "string" && memberIdPattern.test(b.member))) return send(response, 400, { error: "invalid_id" });
      }
      if (!writes.every(b => typeof b.count === "number" && Number.isInteger(b.count) && b.count >= 0 && b.count <= maxCount)) return send(response, 400, { error: "invalid_count" });
      if (new Set(writes.map(b => b.member)).size !== writes.length) return send(response, 400, { error: "invalid_body" });
      if (live(minute, 60_000, now) && minute.count + writes.length > badgesPerMinute) return send(response, 429, { error: "quota_exceeded" }, wait(minute, 60_000, now));
      count(minute, 60_000, now, writes.length);
      const answer = { set: [] as string[], skipped: [] as string[] };
      for (const b of writes) {
        if (!access(b.member)) {
          answer.skipped.push(b.member);
          continue;
        }
        if (b.count === 0) chest.badges.delete(b.member);
        else chest.badges.set(b.member, b.count);
        answer.set.push(b.member);
      }
      return send(response, 200, answer);
    }
    if (url.pathname === "/notifications/withdraw") {
      if (!keys("key", "members")) return send(response, 400, { error: "invalid_body" });
      const key = command!["key"];
      if (typeof key !== "string" || !keyPattern.test(key)) return send(response, 400, { error: "invalid_key" });
      const named = command!["members"] === undefined ? null : recipients(command!["members"]);
      if (named !== null && !Array.isArray(named)) return send(response, 400, named);
      drop(n => n.key === key && (named === null || named.includes(n.member)));
      return send(response, 204);
    }
    if (!keys("members", "title", "body", "path", "key")) return send(response, 400, { error: "invalid_body" });
    const { title, body: text, path, key } = command!;
    const ids = recipients(command!["members"]);
    if (!Array.isArray(ids)) return send(response, 400, ids);
    if (typeof title !== "string" || [...title].length < 1 || [...title].length > maxTitle || cleanTitle(title) === "") return send(response, 400, { error: "invalid_title" });
    if (text !== undefined && (typeof text !== "string" || [...text].length > maxText)) return send(response, 400, { error: "invalid_text" });
    if (path !== undefined && !isPath(path)) return send(response, 400, { error: "invalid_path" });
    if (key !== undefined && (typeof key !== "string" || !keyPattern.test(key))) return send(response, 400, { error: "invalid_key" });
    const kept = ids.filter(access);
    if (live(hour, 3_600_000, now) && hour.count + kept.length > recipientsPerHour) return send(response, 429, { error: "quota_exceeded" }, wait(hour, 3_600_000, now));
    const full = kept.map(id => days.get(id)).filter((w): w is Window => live(w, 86_400_000, now) && w!.count >= itemsPerDay);
    if (full.length > 0) return send(response, 429, { error: "quota_exceeded" }, wait(full.reduce((a, b) => a.start > b.start ? a : b), 86_400_000, now));
    count(hour, 3_600_000, now, kept.length);
    const cleaned = typeof text === "string" ? cleanText(text) : "";
    for (const id of kept) {
      if (!days.has(id)) days.set(id, { start: 0, count: 0 });
      count(days.get(id)!, 86_400_000, now, 1);
      if (key !== undefined) drop(n => n.member === id && n.key === key);
      chest.notifications.push({ member: id, title: cleanTitle(title), ...(cleaned ? { body: cleaned } : {}), path: (path as string | undefined) ?? "/chest", ...(key !== undefined ? { key: key as string } : {}) });
    }
    send(response, 200, { delivered: kept, skipped: ids.filter(id => !access(id)) });
  }

  // Events between tools (Proposal (studio)): what the tool publishes.
  const emits = new Set(options.emits ?? []);
  const publishedKeys = new Map<string, string>();
  async function eventsRoute(request: IncomingMessage, response: ServerResponse): Promise<void> {
    if (request.method !== "POST") return send(response, 404, { error: "not_found" });
    const raw = await body(request, 32 << 10);
    let e: Record<string, unknown>;
    try { e = JSON.parse(raw?.toString() ?? "") as Record<string, unknown>; } catch { return send(response, 400, { error: "invalid_event" }); }
    const type = e["type"], data = e["data"], key = e["key"];
    if (typeof type !== "string" || !emits.has(type) || data === null || typeof data !== "object" || Array.isArray(data)) return send(response, 400, { error: "invalid_event" });
    if (typeof key === "string" && publishedKeys.has(key)) return send(response, 200, { id: publishedKeys.get(key), receivers: options.receivers ?? 0 });
    const id = newId("evt_");
    chest.published.push({ id, type, data: data as Record<string, unknown>, ...(typeof key === "string" ? { key } : {}) });
    if (typeof key === "string") publishedKeys.set(key, id);
    send(response, 201, { id, receivers: options.receivers ?? 0 });
  }

  // Mail (Proposal (studio)): send, status, mailboxes.
  const mailOptions = options.mail ?? {};
  const domain = mailOptions.domain ?? "company.test";
  const mailboxes = new Set(mailOptions.mailboxes ?? []);
  const suppressed = new Set((mailOptions.suppressed ?? []).map(a => a.toLowerCase()));
  const sentKeys = new Map<string, FakeMail>();
  const mailDay: Window = { start: 0, count: 0 };
  const newId = (prefix: string) => prefix + Array.from(randomBytes(26), b => "abcdefghijklmnopqrstuvwxyz234567"[b & 31]).join("");
  async function mailRoute(request: IncomingMessage, response: ServerResponse, url: URL): Promise<void> {
    if (!capabilities.has("mail")) return send(response, 404, { error: "not_found" });
    const box = /^\/mail\/mailboxes\/([a-z][a-z0-9-]{0,31})$/u.exec(url.pathname);
    if (request.method === "GET" && box) return mailboxes.has(box[1]!) ? send(response, 200, { address: `${box[1]}@${domain}` }) : send(response, 404, { error: "not_found" });
    const one = /^\/mail\/messages\/(msg_[a-z2-7]{26})$/u.exec(url.pathname);
    if (request.method === "GET" && one) {
      const m = chest.outbox.find(x => x.id === one[1]);
      return m ? send(response, 200, { id: m.id, status: m.status, at: new Date().toISOString() }) : send(response, 404, { error: "not_found" });
    }
    if (request.method !== "POST" || url.pathname !== "/mail/messages") return send(response, 404, { error: "not_found" });
    const raw = await body(request, 16 << 20);
    if (raw === null) return send(response, 413, { error: "too_large" });
    let m: Record<string, unknown>;
    try { m = JSON.parse(raw.toString()) as Record<string, unknown>; } catch { return send(response, 400, { error: "invalid_message" }); }
    if (typeof m["key"] === "string" && sentKeys.has(m["key"])) {
      const first = sentKeys.get(m["key"])!;
      return send(response, 200, { id: first.id, message_id: first.messageId });
    }
    const resolve = (list: unknown): string[] | null => {
      if (!Array.isArray(list)) return null;
      const out: string[] = [];
      for (const r of list) {
        if (typeof r === "string") out.push(r);
        else if (r && typeof r === "object" && typeof (r as { member?: unknown }).member === "string") {
          const who = chest.members.find(x => x.id === (r as { member: string }).member);
          if (!who?.email) return null;
          out.push(who.email);
        } else return null;
      }
      return out;
    };
    const to = resolve(m["to"]), cc = resolve(m["cc"] ?? []);
    if (!to || !cc || to.length < 1) return send(response, 400, { error: "invalid_address" });
    if (m["mailbox"] !== undefined && !mailboxes.has(String(m["mailbox"]))) return send(response, 400, { error: "invalid_mailbox" });
    const allowed = [...to, ...cc].filter(a => !suppressed.has(a.toLowerCase()));
    if (allowed.length === 0) return send(response, 422, { error: "suppressed" });
    const now = Date.now();
    if (live(mailDay, 86_400_000, now) && mailDay.count >= (mailOptions.perDay ?? 500)) return send(response, 429, { error: "quota_exceeded" }, wait(mailDay, 86_400_000, now));
    count(mailDay, 86_400_000, now, 1);
    const attachments = Array.isArray(m["attachments"]) ? (m["attachments"] as Record<string, unknown>[]).map(a => typeof a["file"] === "string"
      ? { name: String(a["name"] ?? a["file"]), type: files.get(a["file"])?.type ?? "application/octet-stream", size: files.get(a["file"])?.data.byteLength ?? 0 }
      : { name: String(a["name"]), type: String(a["type"]), size: Buffer.from(String(a["content"] ?? ""), "base64").byteLength }) : [];
    const id = newId("msg_");
    const kept: FakeMail = {
      id, messageId: `<${id}@${domain}>`,
      from: typeof m["mailbox"] === "string" ? `${m["mailbox"]}@${domain}` : `no-reply@${domain}`,
      fromName: typeof m["from_name"] === "string" ? m["from_name"] : null,
      to: to.filter(a => allowed.includes(a)), cc: cc.filter(a => allowed.includes(a)),
      subject: String(m["subject"]), text: String(m["text"]),
      ...(typeof m["html"] === "string" ? { html: m["html"] } : {}),
      ...(typeof m["reply_to"] === "string" ? { replyTo: m["reply_to"] } : {}),
      ...(typeof m["in_reply_to"] === "string" ? { inReplyTo: m["in_reply_to"] } : {}),
      ...(Array.isArray(m["references"]) ? { references: m["references"] as string[] } : {}),
      attachments,
      ...(typeof m["key"] === "string" ? { key: m["key"] } : {}),
      status: "sent",
    };
    chest.outbox.push(kept);
    if (kept.key) sentKeys.set(kept.key, kept);
    send(response, 201, { id, message_id: kept.messageId });
  }

  // The acknowledgment of an erasure the tool was told of (emit).
  async function erasuresRoute(request: IncomingMessage, response: ServerResponse, url: URL): Promise<void> {
    if (!receives.includes("member.*")) return send(response, 403, { error: "capability_not_granted" });
    const done = /^\/erasures\/([^/]+)\/done$/u.exec(url.pathname);
    if (request.method !== "POST" || !done || url.search) return send(response, 404, { error: "not_found" });
    const id = done[1]!;
    if (!/^era_[a-z2-7]{26}$/u.test(id)) return send(response, 400, { error: "invalid_id" });
    if (!erasures.has(id)) return send(response, 404, { error: "erasure_not_found" });
    if (!chest.acknowledged.includes(id)) chest.acknowledged.push(id);
    send(response, 204);
  }

  // The team host's own routes, which a Chest's front serves beside the
  // tool: the upload a member's browser sends, the signed links, the members'
  // photos. A harness relays /_chest/ of its host here (origin).
  async function frontRoute(request: IncomingMessage, response: ServerResponse, url: URL): Promise<void> {
    const upload = /^\/_chest\/(files\/)?upload\/([A-Za-z0-9_-]+\.up)$/u.exec(url.pathname);
    if (upload && request.method === "PUT") {
      const token = upload[2]!, grant = uploads.get(token);
      uploads.delete(token);
      // A private token on the team host's route, a public one on the public
      // host's: never the other way round.
      if (!grant || grant.expires < Date.now() || grant.public !== (upload[1] === undefined)) return send(response, 403, { error: "invalid_token" });
      const type = (request.headers["content-type"] ?? "application/octet-stream").split(";")[0]!.trim().toLowerCase();
      if (grant.types.length > 0 && !grant.types.some(t => t === type || (t.endsWith("/*") && type.startsWith(t.slice(0, -1))))) return send(response, 415, { error: "type_refused" });
      const data = await body(request, grant.maxSize);
      if (data === null) return send(response, 413, { error: "too_large" });
      const total = [...files.values()].reduce((sum, f) => sum + f.data.byteLength, 0);
      if (total + data.length > maxTotal || files.size >= maxObjects) return send(response, 429, { error: "quota_exceeded" });
      const extension = (type.split("/")[1] ?? "bin").replace(/[^a-z0-9]/gu, "").slice(0, 8) || "bin";
      const name = grant.name.endsWith("/") ? grant.name + randomBytes(10).toString("hex") + "." + (extension === "jpeg" ? "jpg" : extension) : grant.name;
      const kept = { data: new Uint8Array(data), type, updated: new Date().toISOString() };
      files.set(name, kept);
      return send(response, 201, { name, type, size: data.length });
    }
    const link = /^\/_chest\/files\/([A-Za-z0-9_-]+)\.fake$/u.exec(url.pathname);
    if (link && request.method === "GET") {
      const object = files.get(Buffer.from(link[1]!, "base64url").toString());
      if (!object) return send(response, 404, { error: "not_found" });
      return void response.writeHead(200, { "Content-Type": object.type, "Content-Length": String(object.data.byteLength), "Cache-Control": "private, max-age=900" }).end(object.data);
    }
    const shared = /^\/_chest\/public\/(.+)$/u.exec(url.pathname);
    if (shared && request.method === "GET") {
      const object = storage.publicFiles ? files.get("public/" + decodeURIComponent(shared[1]!)) : undefined;
      if (!object) return send(response, 404, { error: "not_found" });
      return void response.writeHead(200, { "Content-Type": object.type, "Content-Length": String(object.data.byteLength), "Cache-Control": "public, max-age=3600" }).end(object.data);
    }
    const photo = /^\/_chest\/members\/(mbr_[a-z2-7]{26})\/photo$/u.exec(url.pathname);
    if (photo && request.method === "GET") {
      const m = chest.members.find(x => x.id === photo[1]);
      if (!m) return send(response, 404, { error: "not_found" });
      // A drawn picture: the initials on a colour of the identifier.
      const initials = ((m.firstName[0] ?? "") + (m.lastName[0] ?? "") || m.name.slice(0, 1)).toUpperCase().replace(/[<>&"']/gu, "");
      const hue = [...m.id].reduce((h, c) => (h * 31 + c.charCodeAt(0)) % 360, 0);
      const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64"><rect width="64" height="64" fill="hsl(${hue} 45% 42%)"/><text x="32" y="41" font-family="sans-serif" font-size="24" font-weight="600" fill="#fff" text-anchor="middle">${initials}</text></svg>`;
      return void response.writeHead(200, { "Content-Type": "image/svg+xml", "Content-Length": String(Buffer.byteLength(svg)) }).end(svg);
    }
    send(response, 404, { error: "not_found" });
  }

  const server = createServer((request, response) => {
    const url = new URL(request.url ?? "/", "http://127.0.0.1");
    const route = url.pathname.startsWith("/_chest/") ? frontRoute
      : url.pathname.startsWith("/erasures/") ? erasuresRoute
      : url.pathname.startsWith("/mail/") ? mailRoute
      : url.pathname === "/events" ? eventsRoute
      : url.pathname === "/members" || url.pathname.startsWith("/members/") || url.pathname === "/groups" ? members
      : url.pathname === "/files" || url.pathname.startsWith("/files/") ? filesRoute
      : url.pathname === "/badges" || url.pathname.startsWith("/badges/") || url.pathname.startsWith("/notifications") ? notificationsRoute : null;
    if (!route) return send(response, 404, { error: "not_found" });
    route(request, response, url).catch(() => { if (!response.headersSent) send(response, 503, { error: "unavailable" }); else response.destroy(); });
  });
  await new Promise<void>(resolve => server.listen(0, "127.0.0.1", resolve));
  const saved = Object.fromEntries(["CHEST_API", "CHEST_TOKEN", "CHEST_TOOL", "CHEST_TIMEZONE"].map(name => [name, process.env[name]]));
  chest.api = "http://127.0.0.1:" + (server.address() as AddressInfo).port;
  const zone = options.timeZone ?? "Europe/Paris";
  Object.assign(process.env, { CHEST_API: chest.api, CHEST_TOKEN: token, CHEST_TOOL: tool, CHEST_TIMEZONE: zone });
  forget();
  chest.emit = async (event, to) => {
    const id = event.id ?? "evt_" + Array.from(randomBytes(26), b => "abcdefghijklmnopqrstuvwxyz234567"[b & 31]).join("");
    const body = JSON.stringify({ id, type: event.type, occurredAt: event.occurredAt ?? new Date().toISOString(), data: event.data });
    if (event.type === "member.erased") erasures.add(event.data.erasure);
    const request = new Request(typeof to === "string" ? to.replace(/\/$/u, "") + "/chest-events" : "http://tool.test/chest-events", { method: "POST", headers: { "Content-Type": "application/json", "Chest-Event": signEvent(id, body, { token, tool }) }, body });
    const answer = typeof to === "string" ? await fetch(request, { redirect: "manual" }) : await to(request);
    await answer.body?.cancel();
    return answer.status;
  };
  // run delivers a run of a declared schedule to POST /chest-jobs/<name>,
  // signed as the Chest signs it (Chest-Job), and says the status answered.
  chest.run = async (name, to, runOptions = {}) => {
    if (!chest.schedules.some(s => s.name === name)) throw new Error(`fakeChest: no schedule named ${name} (options.schedules)`);
    const id = runOptions.id ?? "run_" + Array.from(randomBytes(26), b => "abcdefghijklmnopqrstuvwxyz234567"[b & 31]).join("");
    const scheduledAt = runOptions.scheduledAt ?? new Date(Math.floor(Date.now() / 60000) * 60000).toISOString();
    const attempt = runOptions.attempt ?? 1;
    const body = JSON.stringify({ id, name, scheduledAt, attempt, timeZone: zone });
    const request = new Request((typeof to === "string" ? to.replace(/\/$/u, "") : "http://tool.test") + "/chest-jobs/" + name, { method: "POST", headers: { "Content-Type": "application/json", "Chest-Job": signEvent(id, body, { token, tool, label: "Chest-Job v1" }) }, body });
    const answer = typeof to === "string" ? await fetch(request, { redirect: "manual" }) : await to(request);
    await answer.body?.cancel();
    chest.runs.push({ id, name, scheduledAt, attempt, status: answer.status });
    return answer.status;
  };
  // deliver hands the tool an event of another tool (its source is the part
  // of the type before the first dot), signed as the Chest signs events.
  chest.deliver = async (event, to) => {
    const id = event.id ?? newId("evt_");
    const source = event.source ?? event.type.split(".")[0]!;
    const body = JSON.stringify({ id, type: event.type, source, occurredAt: event.occurredAt ?? new Date().toISOString(), data: event.data });
    const request = new Request((typeof to === "string" ? to.replace(/\/$/u, "") : "http://tool.test") + "/chest-events", { method: "POST", headers: { "Content-Type": "application/json", "Chest-Event": signEvent(id, body, { token, tool }) }, body });
    const answer = typeof to === "string" ? await fetch(request, { redirect: "manual" }) : await to(request);
    await answer.body?.cancel();
    return answer.status;
  };
  // receive delivers a message to one of the tool's mailboxes: its
  // attachments stored in the tool's files first (mail/…), then POST
  // /chest-mail, signed as the Chest signs it (Chest-Mail).
  chest.receive = async (message, to) => {
    const id = newId("rcv_");
    const stored = (message.attachments ?? []).map(a => {
      const data = typeof a.content === "string" ? new TextEncoder().encode(a.content) : a.content;
      const extension = (a.name.split(".").pop() ?? "bin").toLowerCase().replace(/[^a-z0-9]/gu, "").slice(0, 8) || "bin";
      const file = `mail/${randomBytes(10).toString("hex")}.${extension}`;
      files.set(file, { data, type: a.type, updated: new Date().toISOString() });
      return { file, name: a.name, type: a.type, size: data.byteLength };
    });
    const body = JSON.stringify({
      id, mailbox: message.mailbox, from: { address: message.from, name: message.fromName ?? null }, to: message.to ?? [`${message.mailbox}@${domain}`], cc: message.cc ?? [],
      subject: message.subject, text: message.text, html: message.html ?? null, message_id: `<${id}@sender.test>`, in_reply_to: message.inReplyTo ?? null, references: message.references ?? [],
      attachments: stored, received_at: new Date().toISOString(), spam: message.spam ?? 0,
    });
    const request = new Request((typeof to === "string" ? to.replace(/\/$/u, "") : "http://tool.test") + "/chest-mail", { method: "POST", headers: { "Content-Type": "application/json", "Chest-Mail": signEvent(id, body, { token, tool, label: "Chest-Mail v1" }) }, body });
    const answer = typeof to === "string" ? await fetch(request, { redirect: "manual" }) : await to(request);
    await answer.body?.cancel();
    return answer.status;
  };
  // upload plays a member's browser sending a file to an uploadUrl answer.
  chest.upload = async (link, data, type) => {
    const path = new URL(link).pathname;
    return fetch(chest.api + path, { method: "PUT", body: typeof data === "string" ? data : new Uint8Array(data), headers: { "Content-Type": type } });
  };
  chest.close = async () => {
    server.closeAllConnections();
    await new Promise<void>(resolve => server.close(() => resolve()));
    for (const [name, value] of Object.entries(saved)) {
      if (value === undefined) delete process.env[name];
      else process.env[name] = value;
    }
    forget();
  };
  return chest;
}
