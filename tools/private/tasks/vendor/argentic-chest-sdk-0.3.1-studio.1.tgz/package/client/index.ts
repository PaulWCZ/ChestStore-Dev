// The package root: every published module a tool's code uses (tool contract
// v2). Each one is also its own subpath (@argentic/chest-sdk/member, /chest,
// /database, /files, /members, /notifications, /events, /ai, /errors), which
// pulls in nothing else. The files, members, notifications, events and ai
// APIs are namespaces here, as their names (get, list, stat, move, notify,
// verify, chat…) are too plain to stand alone. @argentic/chest-sdk/testing is for a tool's tests only, and
// is not here.
export * from "./src/errors.js";
export * from "./src/member.js";
export * from "./src/chest.js";
export * from "./src/database.js";
export * as files from "./src/files.js";
export * as members from "./src/members.js";
export * as notifications from "./src/notifications.js";
export * as events from "./src/events.js";
export * as ai from "./src/ai.js";
// Studio proposals (not in 0.3.0): each its own subpath too (/schedules,
// /mail, /visitors, /checks, /calendar, /webhooks), a namespace here.
export * as schedules from "./src/schedules.js";
export * as mail from "./src/mail.js";
export * as visitors from "./src/visitors.js";
export * as checks from "./src/checks.js";
export * as calendar from "./src/calendar.js";
export * as webhooks from "./src/webhooks.js";
