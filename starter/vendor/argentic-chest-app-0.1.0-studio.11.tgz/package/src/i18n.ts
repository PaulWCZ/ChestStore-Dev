import { AppError } from "./tool.ts";

// Words and formats, without the tool's catalogues: fill a text, choose a
// plural form, write dates, numbers and amounts in a reader's language and
// time zone, find a visitor's language. Safe in the browser too.

// A calendar day "YYYY-MM-DD" (a timestamp's day part too) as a Date at
// UTC midnight; one that does not exist is a refusal.
function dayOf(iso: string): Date {
  const m = /^(\d{4})-(\d{2})-(\d{2})/u.exec(typeof iso === "string" ? iso : "");
  const at = m ? new Date(Date.UTC(Number(m[1]), Number(m[2]) - 1, Number(m[3]))) : null;
  if (!m || !at || at.getUTCFullYear() !== Number(m[1]) || at.getUTCMonth() + 1 !== Number(m[2]) || at.getUTCDate() !== Number(m[3])) throw new AppError("invalid");
  return at;
}

// fill puts values in a text's {placeholders}.
export const fill = (text: string, values: Record<string, string | number> = {}): string =>
  text.replace(/\{(\w+)\}/gu, (whole, key: string) => (key in values ? String(values[key]) : whole));

export type Plural = { readonly zero?: string; readonly one: string; readonly other: string };

// plural(locale, forms, n): the form of n in that language, {count}
// filled (French says "0 note", English "0 notes"). In an island too.
export function plural(locale: string, forms: Plural, n: number, values: Record<string, string | number> = {}): string {
  const tag = locale === "en" ? "en-GB" : locale;
  return fill(n === 0 && forms.zero !== undefined ? forms.zero : once(`p|${tag}`, () => new Intl.PluralRules(tag)).select(n) === "one" ? forms.one : forms.other, { count: numberFormat(tag).format(n), ...values });
}

// The language a tool speaks for a language tag: itself when the tool
// speaks it, else the first of the tool's languages (its source).
export const localeIn = <L extends string>(locales: readonly L[], language: string | null | undefined): L =>
  (locales as readonly (string | null | undefined)[]).includes(language) ? language as L : locales[0]!;

// A visitor's language on the public part: their choice (the cookie the
// switch sets), else the first of Accept-Language the tool speaks, else
// the Chest's own language, else the tool's first.
export function publicLocale<L extends string>(locales: readonly L[], cookie: string | undefined, accept: string | undefined, chestLanguage?: string): L {
  if ((locales as readonly string[]).includes(cookie ?? "")) return cookie as L;
  const ranked = (accept ?? "").split(",").slice(0, 16).map((part, index) => {
    const [tag = "", q] = part.trim().split(";q=");
    return { language: tag.toLowerCase().split("-")[0] ?? "", weight: q === undefined ? 1 : Number(q) || 0, index };
  }).filter(r => r.weight > 0).sort((a, b) => b.weight - a.weight || a.index - b.index);
  return (ranked.map(r => r.language).find(l => (locales as readonly string[]).includes(l)) as L | undefined) ?? localeIn(locales, chestLanguage);
}

// Intl objects are costly and live outside V8's heap: one made per call
// (per row of a page) piles up hundreds of MiB before a GC frees them
// (measured: 427 MiB after 400 renders of a 30-row page). Each is made
// once per language, zone and style, and kept.
type Made = Intl.DateTimeFormat | Intl.NumberFormat | Intl.PluralRules | Intl.RelativeTimeFormat;
const made = new Map<string, Made>();
function once<T extends Made>(key: string, make: () => T): T {
  if (made.size > 500) made.clear();
  let found = made.get(key) as T | undefined;
  if (!found) made.set(key, (found = make()));
  return found;
}
export const dateFormat = (tag: string, timeZone: string, style: Intl.DateTimeFormatOptions): Intl.DateTimeFormat =>
  once(`d|${tag}|${timeZone}|${JSON.stringify(style)}`, () => new Intl.DateTimeFormat(tag, { timeZone, ...style }));
export const numberFormat = (tag: string, style: Intl.NumberFormatOptions = {}): Intl.NumberFormat =>
  once(`n|${tag}|${JSON.stringify(style)}`, () => new Intl.NumberFormat(tag, style));


// How a reader writes dates, times, numbers, amounts and plurals: their
// language and their time zone (a member's own, member.timeZone — where
// their browser is; the company's, chest.timeZone, for a visitor). Made on
// the server for each request: a page is sent already written, never
// formatted again in the browser. No currency: the Chest has none (SDK
// 0.7.0) — an amount is written in its own currency, the ISO 4217 code the
// tool keeps beside it (f.money(cents, "GBP", { cents: true })).
export type Format = ReturnType<typeof formatter>;
// An ISO 4217 code as a tool stores it: three letters, upper case.
export const currencyPattern = /^[A-Z]{3}$/u;
// The decimals of a currency's minor unit (2 for EUR and USD, 0 for JPY,
// 3 for KWD), as Intl knows them: what field.money({ decimals }) and
// readMoney(text, decimals) take for an amount in that currency, and what
// f.money(…, { cents: true }) divides by.
export function currencyDecimals(currency: string): number {
  const code = currency.toUpperCase();
  if (!currencyPattern.test(code)) throw new RangeError(`currencyDecimals: "${currency}" is not an ISO 4217 code`);
  return numberFormat("en", { style: "currency", currency: code }).resolvedOptions().maximumFractionDigits ?? 2;
}
export function formatter(locale: string, timeZone: string) {
  // English as written in Europe (day month year, 24-hour clock).
  const tag = locale === "en" ? "en-GB" : locale;
  const today = (at: Date = new Date()) => {
    const parts = Object.fromEntries(dateFormat("en-US", timeZone, { year: "numeric", month: "2-digit", day: "2-digit" }).formatToParts(at).map(p => [p.type, p.value]));
    return `${parts["year"]}-${parts["month"]}-${parts["day"]}`;
  };
  // The year is written when it is not the reader's current one.
  const otherYear = (year: string) => year !== today().slice(0, 4);
  const yearOf = (value: Date) => dateFormat("en-US", timeZone, { year: "numeric" }).format(value);
  // A wall time that happens twice (the hour clocks go back) says its zone.
  const ambiguous = (value: Date) => {
    const clock = dateFormat("en-US", timeZone, { hour: "2-digit", minute: "2-digit", hourCycle: "h23" });
    const shown = clock.format(value);
    return clock.format(new Date(value.getTime() - 3_600_000)) === shown || clock.format(new Date(value.getTime() + 3_600_000)) === shown;
  };
  const clockStyle = (value: Date): Intl.DateTimeFormatOptions => ({ hour: "2-digit", minute: "2-digit", ...(ambiguous(value) ? { timeZoneName: "short" } : {}) });
  return {
    locale,
    timeZone,
    // An instant (a timestamptz, a Date): in the reader's zone. A calendar
    // day ("2026-10-05", a date column) is f.day's, never these: a day read
    // as an instant shifts in zones west of UTC.
    date: (value: Date) => dateFormat(tag, timeZone, { day: "numeric", month: "short", year: "numeric" }).format(value),
    time: (value: Date) => dateFormat(tag, timeZone, clockStyle(value)).format(value),
    dateTime: (value: Date) => dateFormat(tag, timeZone, { day: "numeric", month: "short", ...(otherYear(yearOf(value)) ? { year: "numeric" } : {}), ...clockStyle(value) }).format(value),
    // A calendar day, "YYYY-MM-DD" (a date column, a field.day): the same
    // day everywhere; its year when it is not the reader's current one.
    // A day that does not exist ("2026-02-31", "") is refused (fail
    // "invalid": the page answers as for an address it cannot show), never
    // written as another day.
    day: (iso: string) => dateFormat(tag, "UTC", { weekday: "short", day: "numeric", month: "short", ...(otherYear(iso.slice(0, 4)) ? { year: "numeric" } : {}) }).format(dayOf(iso)),
    // Today in the reader's zone, "YYYY-MM-DD": a member's own day ("due
    // today" on their page, their reminder). The company's day — a
    // document's date, a company-wide deadline — is chest.today(), and SQL's
    // current_date and now()::date are the company's too (the database
    // session runs in chest.timeZone).
    today,
    number: (n: number) => numberFormat(tag).format(n),
    // An amount in its own currency, the ISO 4217 code kept beside it
    // ("EUR", "GBP", "JPY"): in minor units with { cents: true } (what
    // field.money reads — cents for EUR, yen for JPY: the currency's own
    // decimals), else in units. A code that is not three letters throws (a
    // fault of the tool: its data holds a code it never checked).
    money: (amount: number, currency: string, options: { cents?: boolean } = {}) => {
      const code = currency.toUpperCase();
      if (!currencyPattern.test(code)) throw new RangeError(`f.money: "${currency}" is not an ISO 4217 code (an amount keeps its own: the Chest has no currency)`);
      return numberFormat(tag, { style: "currency", currency: code }).format(options.cents ? amount / 10 ** currencyDecimals(code) : amount);
    },
    // The form of n in this language (French says "0 note", English "0 notes").
    plural: (forms: Plural, n: number, values: Record<string, string | number> = {}) => plural(locale, forms, n, values),
  };
}
